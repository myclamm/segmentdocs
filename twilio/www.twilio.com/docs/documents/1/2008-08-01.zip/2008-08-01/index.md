<div id="version-info" class="alert">
    This document describes Twilio's old 2008-08-01 API. Please use the 
    <a href="/docs/api/rest">latest version</a>.
</div>

# 2008 REST and TwiML

For posterity, you may reference documentation for 2008 version of the core 
Twilio APIs here. However, we recommend that you use the latest
[REST API](/docs/api/rest) and [TwiML API](/docs/api/twiml) if at all possible.